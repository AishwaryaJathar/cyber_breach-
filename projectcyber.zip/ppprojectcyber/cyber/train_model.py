import pandas as pd
import dask.dataframe as dd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import MultinomialNB
from xgboost import XGBClassifier
import joblib
import time
from multiprocessing import Process, freeze_support  # Add freeze_support

def train_and_evaluate(model, X_train, y_train, X_test, y_test, model_name):
    start_time = time.time()
    model.fit(X_train, y_train)
    end_time = time.time()
    accuracy = model.score(X_test, y_test)
    print(f"Accuracy {model_name}: {accuracy:.2f}")
    training_time = end_time - start_time
    return accuracy, training_time

def main():
    # Load your dataset from CSV using Dask
    data = dd.read_csv('./dataset/dataset.csv', dtype={'type': str})

    # Convert Dask DataFrame to Pandas DataFrame for label encoding
    pandas_data = data.compute()

    # Preprocess your data (e.g., convert labels to numerical values)
    label_encoder = LabelEncoder()
    pandas_data['type_encoded'] = label_encoder.fit_transform(pandas_data['type'])
    joblib.dump(label_encoder, './generated_files/label_encoder.pkl')

    # Convert Pandas DataFrame back to Dask DataFrame
    data = dd.from_pandas(pandas_data, npartitions=10)

    # Split the dataset into training and testing sets
    X = data['url']
    y = data['type_encoded']

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Vectorize the URLs using TF-IDF
    tfidf_vectorizer = TfidfVectorizer()
    X_train_tfidf = tfidf_vectorizer.fit_transform(X_train.compute())
    X_test_tfidf = tfidf_vectorizer.transform(X_test.compute())
    
    # Save the TF-IDF vectorizer to a file
    joblib.dump(tfidf_vectorizer, './generated_files/tfidf_vectorizer.pkl')
    
    # Define models and their names
    models = [
    (RandomForestClassifier(n_estimators=100, random_state=42), 'RF'),
        (KNeighborsClassifier(n_neighbors=min(5, len(y_test))), 'KNN'),
        (MultinomialNB(), 'NB'),
        (XGBClassifier(), 'XGBoost')
    ]

    # Train and evaluate models in parallel
    accuracy_scores = {}  # Store accuracy scores
    training_times = {}  # Store training times
    for model, model_name in models:
        accuracy, training_time = train_and_evaluate(model, X_train_tfidf, y_train, X_test_tfidf, y_test, model_name)
        accuracy_scores[model_name] = accuracy
        training_times[model_name] = training_time

    # Save the trained models to files
    for model, model_name in models:
        joblib.dump(model, f'./generated_files/{model_name}_model.pkl')

    # Save the training times and accuracy to text files
    with open('./generated_files/training_time.txt', 'w') as time_file:
        time_file.write(
            f"NB:{training_times['NB']},"
            f"KNN:{training_times['KNN']},"
            f"RF:{training_times['RF']},"
            f"XG:{training_times['XGBoost']}"
        )

    # Save accuracy to a text file
    with open('./generated_files/accuracy.txt', 'w') as accuracy_file:
        accuracy_file.write(
            f"NB:{accuracy_scores['NB']},"
            f"KNN:{accuracy_scores['KNN']},"
            f"RF:{accuracy_scores['RF']},"
            f"XG:{accuracy_scores['XGBoost']}"
        )

if __name__ == '__main__':
    freeze_support()  # Add freeze_support to prevent the error
    main()

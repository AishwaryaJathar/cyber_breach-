from flask import Flask, render_template, request
import joblib
from sklearn.metrics import accuracy_score
import pandas as pd

app = Flask(__name__)
app.config['STATIC_FOLDER'] = 'static'

# Load the trained TF-IDF vectorizer
tfidf_vectorizer = joblib.load('./generated_files/tfidf_vectorizer.pkl')

# Load the trained Random forest model
rf_model = joblib.load('./generated_files/rf_model.pkl')
# Load the trained Naive Bayes model
nbc_model = joblib.load('./generated_files/nbc_model.pkl')
# Load the trained k-Nearest Neighbors (k-NN) model
knn_model = joblib.load('./generated_files/knn_model.pkl')
# Load the trained XGBoost model
xg_model = joblib.load('./generated_files/xgboost_model.pkl')

# Load the label encoder used during model training
label_encoder = joblib.load('./generated_files/label_encoder.pkl')

# Fetch and process the accuracy
with open('./generated_files/accuracy.txt', 'r') as file:
    accuracy = file.read()

# Split the content by commas and labels
accuracy = accuracy.split(',')

# Extract individual training times
accuracy_nb = float(accuracy[0].split(':')[1])*100
accuracy_knn = float(accuracy[1].split(':')[1])*100
accuracy_rf = float(accuracy[2].split(':')[1])*100
accuracy_xg = float(accuracy[3].split(':')[1])*100

# Fetch and process the training times
with open('./generated_files/training_time.txt', 'r') as file:
    training_time_str = file.read()

# Split the content by commas and labels
training_times = training_time_str.split(',')

# Extract individual training times
time_nb = float(training_times[0].split(':')[1])
time_knn = float(training_times[1].split(':')[1])
time_rf = float(training_times[2].split(':')[1])
time_xg = float(training_times[3].split(':')[1])

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        url = request.form['url']
        
        # Vectorize the input URL using the pre-trained TF-IDF vectorizer
        url_tfidf = tfidf_vectorizer.transform([url])
        
        # Make predictions using the pre-trained models
        prediction_nbc = nbc_model.predict(url_tfidf)[0]
        prediction_xg = xg_model.predict(url_tfidf)[0]
        prediction_rf = rf_model.predict(url_tfidf)[0]
        prediction_knn = knn_model.predict(url_tfidf)[0]
        
        # Inverse transform the numerical predictions to get the original labels
        predicted_label_nbc = label_encoder.inverse_transform([prediction_nbc])[0]
        predicted_label_xg = label_encoder.inverse_transform([prediction_xg])[0]
        predicted_label_rf = label_encoder.inverse_transform([prediction_rf])[0]
        predicted_label_knn = label_encoder.inverse_transform([prediction_knn])[0]
        
        # Render the result template with predictions, accuracy, and training times
        return render_template('result.html',
                               pred_nbc=predicted_label_nbc, pred_xg=predicted_label_xg,
                               pred_rf=predicted_label_rf, pred_knn=predicted_label_knn,
                               ac_nbc=accuracy_nb, ac_xg=accuracy_xg,
                               ac_rf=accuracy_rf, ac_knn=accuracy_knn,
                               tt_nb=time_nb, tt_knn=time_knn,
                               tt_rf=time_rf, tt_xg=time_xg)

if __name__ == '__main__':
    app.run(debug=True, port=5001)

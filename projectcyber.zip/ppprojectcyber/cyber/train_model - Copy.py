import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier  # Import k-NN classifier
from sklearn.naive_bayes import MultinomialNB
from xgboost import XGBClassifier  # Import XGBoost classifier
import joblib
import time
import dask.dataframe as dd

# Load your dataset from CSV 
data = dd.read_csv('./dataset/dataset.csv', dtype={'type': str})

# Preprocess your data (e.g., convert labels to numerical values)
label_encoder = LabelEncoder()
data['type_encoded'] = label_encoder.fit_transform(data['type'])

# Split the dataset into training and testing sets
X = data['url']  # URL is your feature
y = data['type_encoded']  # Type is the target variable

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Vectorize the URLs using TF-IDF
tfidf_vectorizer = TfidfVectorizer()
X_train_tfidf = tfidf_vectorizer.fit_transform(X_train)
X_test_tfidf = tfidf_vectorizer.transform(X_test)

# Save the label encoder to a file
joblib.dump(label_encoder, './generated_files/label_encoder.pkl')

# Save the TF-IDF vectorizer to a file
joblib.dump(tfidf_vectorizer, './generated_files/tfidf_vectorizer.pkl')



# Train a Random Forest Classifier
start_time_rf = time.time()
random_forest = RandomForestClassifier(n_estimators=100, random_state=42)
random_forest.fit(X_train_tfidf, y_train)
end_time_rf = time.time()

# Train a k-Nearest Neighbors (k-NN) Classifier
start_time_knn = time.time()
knn_model = KNeighborsClassifier(n_neighbors=5)  # You can adjust the number of neighbors (k) as needed
knn_model.fit(X_train_tfidf, y_train)
end_time_knn = time.time()

# Train a Naive Bayes classifier and measure the time taken
start_time_nb = time.time()
nbc_model = MultinomialNB()
nbc_model.fit(X_train_tfidf, y_train)
end_time_nb = time.time()

# Train an XGBoost Classifier
start_time_xg = time.time()
xgboost_model = XGBClassifier()  # You can adjust hyperparameters as needed
xgboost_model.fit(X_train_tfidf, y_train)
end_time_xg = time.time()

# Evaluate the rf model
accuracy_rf = random_forest.score(X_test_tfidf, y_test)
print(f"Accuracy random forest: {accuracy_rf:.2f}")
training_time_rf = end_time_rf - start_time_rf

# Evaluate the knn model
accuracy_knn = knn_model.score(X_test_tfidf, y_test)
print(f"Accuracy knn : {accuracy_knn:.2f}")
training_time_knn = end_time_knn - start_time_knn

# Evaluate the xg boostmodel
accuracy_xg = xgboost_model.score(X_test_tfidf, y_test)
print(f"Accuracy xgboost: {accuracy_xg:.2f}")
training_time_xg = end_time_xg - start_time_xg

# Evaluate the nbc model
accuracy_nbc = nbc_model.score(X_test_tfidf, y_test)
print(f"Accuracy naive bayes: {accuracy_nbc:.2f}")
training_time_nb = end_time_nb - start_time_nb

with open('./generated_files/accuracy.txt', 'w') as time_file:
     time_file.write(
        f"NB:{accuracy_nbc}," +
        f"KNN:{accuracy_knn}," +
        f"RF:{accuracy_rf}," +
        f"XG:{accuracy_xg}"
    )

# Save the trained model to a file
joblib.dump(random_forest, './generated_files/rf_model.pkl')

# Save the trained k-NN model to a file
joblib.dump(knn_model, './generated_files/knn_model.pkl')

# Save the trained NBC model to a file
joblib.dump(nbc_model, './generated_files/nbc_model.pkl')

# Save the trained XGBoost model to a file
joblib.dump(xgboost_model, './generated_files/xgboost_model.pkl')

# Save the training time to a text file with labels
with open('./generated_files/training_time.txt', 'w') as time_file:
     time_file.write(
        f"NB:{training_time_nb}," +
        f"KNN:{training_time_knn}," +
        f"RF:{training_time_rf}," +
        f"XG:{training_time_xg}"
    )